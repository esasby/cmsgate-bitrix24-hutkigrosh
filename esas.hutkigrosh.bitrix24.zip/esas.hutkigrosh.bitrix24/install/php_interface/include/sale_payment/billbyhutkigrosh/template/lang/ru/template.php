<?
include $_SERVER['DOCUMENT_ROOT']."/bitrix/modules/sale/handlers/paysystem/billby/template/lang/ru/template.php";
